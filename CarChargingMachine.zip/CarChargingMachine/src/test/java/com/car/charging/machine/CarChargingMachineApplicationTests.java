package com.car.charging.machine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarChargingMachineApplicationTests {

	@Test
	void contextLoads() {
	}

}
