package com.car.charging.machine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarChargingMachineApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarChargingMachineApplication.class, args);
	}

}
