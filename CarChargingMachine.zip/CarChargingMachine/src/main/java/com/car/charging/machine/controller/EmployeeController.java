package com.car.charging.machine.controller;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.car.charging.machine.pojo.Employee;
import com.car.charging.machine.service.EmployeeService;

@RestController
@RequestMapping("register")
public class EmployeeController {
	@Autowired
	EmployeeService empService;
	@PostMapping("registerNewUser")
	public String register(@RequestBody Employee emp) {
		int flag=0;
		List<Employee> allEmp =empService.findAll();
		for (Employee employee : allEmp) {
			if(employee.getEmailId().equals(emp.getEmailId()))
			{
				flag=1;
			}
		} 
		if(flag==0) {
			empService.save(emp);
			return "registered successfully";
		}
		else
			return "User is already registered with this emailId";
	}
	@GetMapping("userlogin/{emailId}/{password}")
	public String UserLogin(@PathVariable(value = "emailId") String emailId, @PathVariable(value = "password") String password) 
	{
		Employee emp = empService.findEmployeeById(emailId);
		if(emp==null) {
			return "employee is not registered";
		}
		else if(!((emp.getRole().equals("employee")))) {
			return "user is not employee";
		}
		else if((emp.getRole().equals("employee"))&&(emailId.equals(emp.getEmailId()))&&(password.equals(emp.getPassword()))){
			return "employee login successfully";
		}
		else 
			return "invalid password";
	}
	@GetMapping("adminlogin/{emailId}/{password}")
	public String adminLogin(  @PathVariable(value = "emailId") String emailId, @PathVariable(value = "password") String password)
	{
		Employee emp = empService.findEmployeeById(emailId);
		if(emp==null) {
			return "admin is not registered";
		}
		else if(!((emp.getRole().equals("admin")))) {
			return "user is not admin";
		}
		else if((emp.getRole().equals("admin"))&&(emailId.equals(emp.getEmailId()))&&(password.equals(emp.getPassword()))){
			return "admin login successfully";
		}
		else 
			return "invalid password";
	}
	@GetMapping("validateemailid/{emailId}")
	public String validatingEmailId(@PathVariable(value="emailId") String emailId) {
		Employee emp=empService.findEmployeeById(emailId);
		if(emp!=null)
			return"emailId is valid";
		else
			return "user is not registered";	
	}
	
	@PutMapping("updatePassword/{emailId}/{newPassword}")
	public String updatePassword( @PathVariable(value = "emailId") String emailId, @PathVariable(value = "newPassword") String newPassword)
	{
		Employee emp=empService.findEmployeeById(emailId);
		//System.out.println(emp);
		if(emp.getEmailId().equals(emailId)) {
			emp.setPassword(newPassword);
			empService.save(emp);
		}
		return "data updated successfully";
	}
	/*
	 * @PostMapping("/feedbackandreview") public void feedbackAndReview(@RequestBody
	 * FeedbackAndReview feedandrev) {
	 * 
	 * 
	 * }
	 */
}