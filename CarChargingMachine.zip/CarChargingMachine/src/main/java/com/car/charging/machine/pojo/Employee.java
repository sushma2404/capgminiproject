package com.car.charging.machine.pojo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="registration")
public class Employee {
	@Id
	public String emailId;
	public String fullName;
	public String password;
	public String cityName;
	public String locationName;
	public String machineType;
	public String phoneNumber;
	public String role;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(String emailId, String fullName, String password, String cityName, String locationName,
			String machineType, String phoneNumber, String role) {
		super();
		this.emailId = emailId;
		this.fullName = fullName;
		this.password = password;
		this.cityName = cityName;
		this.locationName = locationName;
		this.machineType = machineType;
		this.phoneNumber = phoneNumber;
		this.role = role;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getLocationName() {
		return locationName;
	}
	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}
	public String getMachineType() {
		return machineType;
	}
	public void setMachineType(String machineType) {
		this.machineType = machineType;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "Employee [emailId=" + emailId + ", fullName=" + fullName + ", password=" + password + ", cityName="
				+ cityName + ", locationName=" + locationName + ", machineType=" + machineType + ", phoneNumber="
				+ phoneNumber + ", role=" + role + "]";
	}

	
}
