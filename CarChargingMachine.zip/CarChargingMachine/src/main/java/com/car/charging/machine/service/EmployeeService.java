package com.car.charging.machine.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.car.charging.machine.pojo.Employee;
import com.car.charging.machine.repository.EmployeeRepository;


@Service
public class EmployeeService {
	@Autowired
	EmployeeRepository empRepo;

	/*
	 * @Autowired FeedbackRepository feedRepo;
	 */
	public Employee save(Employee emp) {
		return empRepo.save(emp);
	}
	public List<Employee> findAll(){
		return  empRepo.findAll();
	}
	public Employee findEmployeeById(String emailId) {
		return empRepo.findById(emailId).orElse(null);
	}
	public void updatePassword(String emailId, Employee emp,String password) {
		// TODO Auto-generated method stub
		Employee empl =empRepo.findById(emailId).orElse(null);
	}
	/*
	 * public FeedbackAndReview savefeedback(FeedbackAndReview feedandreview) {
	 * return feedRepo.save(feedandreview);
	 * 
	 * }
	 */
}
